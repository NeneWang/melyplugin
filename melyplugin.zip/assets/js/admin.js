/**
 * Plugin Template admin js.
 *
 *  @package WordPress Plugin Template/JS
 */

;(function($){
	
	$(document).ready(function(){
		
		
	});
	
})(jQuery);